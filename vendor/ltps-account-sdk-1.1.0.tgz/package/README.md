# 利澤國小獨立校級統一帳號管理中心（`ltps-account-hub` / `@ltps/account-sdk`）

本專案採用 **方案 B（獨立 Firebase 專案 `ltps-account-hub` 作為校級帳號中心 / Token Broker）**，將全校教職員帳號與雙層管理員權限完全獨立於各業務系統之外，可跨多個不同 Firebase 專案提供統一 Google 單一登入與嵌入式帳號管理元件。

## 核心架構

1. **獨立 Firebase 專案（`ltps-account-hub`）**：
   - 使用預設資料庫 **`(default)`** 集中存放全校 `/accounts/{uid}`、`/apps/{appId}`（含 `targetProjectId`）與 `/accountLogs/{logId}`。
   - 獨立 Hosting 站台：**`https://ltps-account-hub.web.app`**（全校帳號管理後台）。
2. **跨專案 Custom Token Broker（`accounts_issueAppToken`）**：
   - 教職員在任一業務系統點擊 Google 登入 → 向 `ltps-account-hub` 完成認證 → 由 `accounts_issueAppToken` 簽發目標專案的 Firebase Custom Token（攜帶該專案專屬的精簡 Custom Claims，並保留既有 UID）。
   - 各業務系統的 `firestore.rules` 直接驗證 Custom Claims，**零額外查表計費、完全突破跨專案限制**。
3. **雙層分權後端模組（Cloud Functions Codebase：`ltps-accounts`）**：
   - 嚴格區分「**校級超級管理員**」與「**單一系統管理員**」。
4. **跨系統共用前端套件（`@ltps/account-sdk`）**：
   - `@ltps/account-sdk/core`：Auth 流程、Claims 解析、Callable API、Excel 範本解析。
   - `@ltps/account-sdk/react`：支援方案 B 跨專案換證（`targetAppAuth`）的 `<LtpsAuthProvider>` 與統一嵌入式 `<LtpsAccountManager />`。

---

## 部署與設定步驟（獨立 Firebase 專案 `ltps-account-hub`）

### 1. 在 Firebase Console 準備 `ltps-account-hub` 專案
1. 建立 Firestore 資料庫（**`(default)`**，位置 `asia-east1 (Taiwan)`，正式環境模式）。
2. 啟用 **Authentication → Google 登入**，並在 **Authorized domains** 加入業務系統網域（例如 `ltps-finance-budget.web.app`）。
3. 升級至 **Blaze 方案**（Cloud Functions v2 與 Secret Manager 所需；學校用量落在免費額度內）。
4. 在 **專案設定 → 一般 → 你的應用程式** 新增一個 Web App，複製設定填入 `console/.env`。

### 2. 設定跨專案簽發金鑰 Secret（`APP_SERVICE_ACCOUNTS`）
從目標專案（如 `ltps-finance-budget`）的 **Firebase Console → 專案設定 → 服務帳戶 → 產生新的私密金鑰** 下載 JSON，包裝成以 `targetProjectId` 為鍵的 JSON 寫入 Secret Manager：

```bash
# 將 finance-sa.json 打包並寫入 ltps-account-hub 的 Secret Manager（不會存入 Git）
node -e "const fs=require('fs'); console.log(JSON.stringify({'ltps-finance-budget': JSON.parse(fs.readFileSync('finance-sa.json','utf8'))}))" \
  | firebase functions:secrets:set APP_SERVICE_ACCOUNTS --project ltps-account-hub
```

### 3. 建置、部署與遷移既有帳號
```bash
npm run build
firebase deploy --project ltps-account-hub

# 初始化 /apps 註冊表並遷移 ltps-finance-budget 既有帳號（保留原 UID）
npm run init:apps
npm run migrate:finance:dry-run
npm run migrate:finance
```

---

## Cloudflare Workers Static Assets 部署（含 RWD ＋ PWA）

專案根目錄已內建 `wrangler.jsonc`（指向 `./console/dist` SPA 靜態資源）與 `console/public/_headers`（含 `Cross-Origin-Opener-Policy: same-origin-allow-popups` 支援 Google 彈窗登入）：

1. 在 Cloudflare Dashboard → **Workers & Pages** → `ltps-account-hub` → **Settings → Build**：
   - **Build command**：`npm run build`
   - **Deploy command**：`npx wrangler deploy`
   - **Build variables**（新增以下 6 組）：
     - `VITE_FIREBASE_API_KEY`
     - `VITE_FIREBASE_AUTH_DOMAIN`
     - `VITE_FIREBASE_PROJECT_ID`
     - `VITE_FIREBASE_STORAGE_BUCKET`
     - `VITE_FIREBASE_MESSAGING_SENDER_ID`
     - `VITE_FIREBASE_APP_ID`
2. 部署取得 Cloudflare 網址（例如 `ltps-account-hub.<subdomain>.workers.dev` 或自訂網域）後，到 **Firebase Console → `ltps-account-hub` → Authentication → Settings → Authorized domains** 加入該網域即可使用 Google 登入與 PWA 安裝。

